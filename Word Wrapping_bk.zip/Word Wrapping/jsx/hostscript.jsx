// JSX script for Word Wrapping CEP Extension
// This script runs in the After Effects environment

function createTextLayer(text, comp) {
    try {
        if (!comp || !(comp instanceof CompItem)) {
            alert("Please select a composition first.");
            return false;
        }
        
        var textLayer = comp.layers.addText(text);
        textLayer.name = "Word Wrapped Text";
        
        // Position the text layer at center of composition
        textLayer.position.setValue([comp.width / 2, comp.height / 2]);
        
        // Set initial text properties
        var textDocument = textLayer.property("Source Text").value;
        textDocument.fontSize = 24;
        textDocument.fillColor = [1, 1, 1]; // White text
        textDocument.strokeColor = [0, 0, 0]; // Black stroke
        textDocument.strokeWidth = 1;
        
        textLayer.property("Source Text").setValue(textDocument);
        
        return true;
    } catch (error) {
        alert("Error creating text layer: " + error.toString());
        return false;
    }
}

function applyWordWrapping(textLayer, width, lineHeight) {
    try {
        if (!textLayer || !(textLayer instanceof TextLayer)) {
            alert("Please select a text layer first.");
            return false;
        }
        
        var textDocument = textLayer.property("Source Text").value;
        
        // Apply word wrapping using paragraph box
        textDocument.boxTextSize = [width, 0]; // 0 height means auto-height
        textDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
        textDocument.leading = lineHeight * 100; // Convert to percentage
        
        // Apply the changes
        textLayer.property("Source Text").setValue(textDocument);
        
        return true;
    } catch (error) {
        alert("Error applying word wrapping: " + error.toString());
        return false;
    }
}

function getSelectedTextLayer() {
    try {
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            return null;
        }
        
        var selectedLayers = comp.selectedLayers;
        if (selectedLayers.length === 0) {
            return null;
        }
        
        var layer = selectedLayers[0];
        if (layer instanceof TextLayer) {
            return layer;
        }
        
        return null;
    } catch (error) {
        return null;
    }
}

function getCompositionInfo() {
    try {
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            return null;
        }
        
        return {
            name: comp.name,
            width: comp.width,
            height: comp.height,
            duration: comp.duration,
            frameRate: comp.frameRate
        };
    } catch (error) {
        return null;
    }
}

// Export functions for CEP extension to use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        createTextLayer: createTextLayer,
        applyWordWrapping: applyWordWrapping,
        getSelectedTextLayer: getSelectedTextLayer,
        getCompositionInfo: getCompositionInfo
    };
}
