# Word Wrapping CEP Extension for After Effects

A Common Extensibility Platform (CEP) extension for Adobe After Effects that provides advanced text wrapping and formatting capabilities.

## Features

- **Text Layer Creation**: Create new text layers directly from the extension
- **Word Wrapping**: Apply automatic word wrapping with customizable width and line height
- **Live Preview**: See how your text will look before applying it to After Effects
- **Modern UI**: Clean, responsive interface that adapts to After Effects themes

## Installation

### Method 1: Manual Installation (Recommended for Development)

1. **Locate CEP Extensions Directory**:
   - **Windows**: `C:\Users\[USERNAME]\AppData\Roaming\Adobe\CEP\extensions\`
   - **macOS**: `~/Library/Application Support/Adobe/CEP/extensions/`

2. **Copy Extension**:
   - Copy the entire `Word Wrapping` folder to the CEP extensions directory
   - Rename it to `com.example.wordwrapping` (or your preferred bundle ID)

3. **Enable Developer Mode**:
   - Open After Effects
   - Go to `Help > Enable Developer Mode` (if available)
   - Or manually edit the registry/plist files

### Method 2: Package Installation

1. Create a `.zxp` package using Adobe Extension Builder or similar tools
2. Install using Adobe Extension Manager or ZXP Installer

## Usage

1. **Open the Extension**:
   - In After Effects, go to `Window > Extensions > Word Wrapping`
   - Or use the menu: `Window > Word Wrapping`

2. **Create Text Layer**:
   - Enter your text in the text area
   - Set desired wrap width and line height
   - Click "Create Text Layer" to add it to your composition

3. **Apply Word Wrapping**:
   - Select an existing text layer in your composition
   - Adjust wrap width and line height as needed
   - Click "Apply Word Wrapping" to update the selected layer

## File Structure

```
Word Wrapping/
├── CSXS/
│   └── manifest.xml          # Extension manifest and configuration
├── css/
│   └── style.css             # Extension styling
├── js/
│   ├── libs/
│   │   └── CSInterface.js    # Adobe CEP interface library
│   └── main.js               # Main extension logic
├── jsx/
│   └── hostscript.jsx        # After Effects JSX scripts
├── index.html                # Main extension interface
└── README.md                 # This file
```

## Development

### Prerequisites

- Adobe After Effects CC 2015 or later
- CEP 7.0 or later
- Web development knowledge (HTML, CSS, JavaScript)
- Basic understanding of After Effects scripting (JSX)

### Customization

- **UI**: Modify `css/style.css` and `index.html` for interface changes
- **Functionality**: Edit `js/main.js` for extension behavior
- **After Effects Integration**: Update `jsx/hostscript.jsx` for AE-specific features

### Testing

1. Enable developer mode in After Effects
2. Make changes to your extension files
3. Reload the extension (usually by closing and reopening it)
4. Test functionality in After Effects

## Troubleshooting

### Extension Not Appearing

- Check that the extension is in the correct CEP directory
- Verify the manifest.xml file is valid
- Ensure After Effects version compatibility
- Check for JavaScript errors in the browser console

### Functionality Issues

- Verify a composition is active in After Effects
- Ensure text layers are selected when applying wrapping
- Check that the JSX scripts are executing properly

### Performance Issues

- Large text blocks may cause delays
- Complex compositions might slow down text operations
- Consider breaking very long text into multiple layers

## API Reference

### JavaScript Functions

- `createTextLayer()`: Creates a new text layer in After Effects
- `applyWordWrapping()`: Applies word wrapping to selected text layer
- `updatePreview()`: Updates the live preview display

### JSX Functions

- `createTextLayer(text, comp)`: Creates text layer in AE
- `applyWordWrapping(textLayer, width, lineHeight)`: Applies wrapping
- `getSelectedTextLayer()`: Gets currently selected text layer
- `getCompositionInfo()`: Retrieves composition details

## License

This project is provided as-is for educational and development purposes. Please ensure compliance with Adobe's CEP licensing requirements for production use.

## Support

For issues and questions:
1. Check the troubleshooting section above
2. Review Adobe's CEP documentation
3. Check After Effects scripting forums
4. Verify your After Effects and CEP versions

## Version History

- **v1.0.0**: Initial release with basic text wrapping functionality
  - Text layer creation
  - Word wrapping with customizable parameters
  - Live preview system
  - Modern, responsive UI
