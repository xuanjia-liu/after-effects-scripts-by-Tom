// Main JavaScript file for Word Wrapping CEP Extension
(function() {
    'use strict';
    
    // Initialize CSInterface
    var csInterface = new CSInterface();
    
    // DOM elements
    var textInput = document.getElementById('textInput');
    var wrapWidth = document.getElementById('wrapWidth');
    var lineHeight = document.getElementById('lineHeight');
    var createTextBtn = document.getElementById('createText');
    var applyWrappingBtn = document.getElementById('applyWrapping');
    var textPreview = document.getElementById('textPreview');
    
    // Initialize the extension
    function init() {
        console.log('Word Wrapping Extension initialized');
        
        // Set up event listeners
        createTextBtn.addEventListener('click', createTextLayer);
        applyWrappingBtn.addEventListener('click', applyWordWrapping);
        
        // Set up input change listeners for live preview
        textInput.addEventListener('input', updatePreview);
        wrapWidth.addEventListener('input', updatePreview);
        lineHeight.addEventListener('input', updatePreview);
        
        // Initial preview update
        updatePreview();
        
        // Set theme
        setTheme();
    }
    
    // Create text layer in After Effects
    function createTextLayer() {
        var text = textInput.value.trim();
        if (!text) {
            alert('Please enter some text first.');
            return;
        }
        
        // Execute JSX script to create text layer
        var jsxScript = `
            try {
                var comp = app.project.activeItem;
                if (!comp || !(comp instanceof CompItem)) {
                    alert("Please select a composition first.");
                    return;
                }
                
                var textLayer = comp.layers.addText("${text.replace(/"/g, '\\"')}");
                textLayer.name = "Word Wrapped Text";
                
                // Position the text layer
                textLayer.position.setValue([comp.width / 2, comp.height / 2]);
                
                alert("Text layer created successfully!");
            } catch (error) {
                alert("Error creating text layer: " + error.toString());
            }
        `;
        
        csInterface.evalScript(jsxScript, function(result) {
            console.log('Text layer creation result:', result);
        });
    }
    
    // Apply word wrapping to selected text layer
    function applyWordWrapping() {
        var width = parseInt(wrapWidth.value);
        var height = parseFloat(lineHeight.value);
        
        if (isNaN(width) || isNaN(height)) {
            alert('Please enter valid numbers for width and line height.');
            return;
        }
        
        // Execute JSX script to apply word wrapping
        var jsxScript = `
            try {
                var comp = app.project.activeItem;
                if (!comp || !(comp instanceof CompItem)) {
                    alert("Please select a composition first.");
                    return;
                }
                
                var selectedLayers = comp.selectedLayers;
                if (selectedLayers.length === 0) {
                    alert("Please select a text layer first.");
                    return;
                }
                
                var textLayer = selectedLayers[0];
                if (!(textLayer instanceof TextLayer)) {
                    alert("Please select a text layer.");
                    return;
                }
                
                var textDocument = textLayer.property("Source Text").value;
                var textValue = textDocument.text;
                
                // Apply word wrapping using paragraph box
                textDocument.boxTextSize = [${width}, 0]; // 0 height means auto-height
                textDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
                textDocument.leading = ${height * 100}; // Convert to percentage
                
                textLayer.property("Source Text").setValue(textDocument);
                
                alert("Word wrapping applied successfully!");
            } catch (error) {
                alert("Error applying word wrapping: " + error.toString());
            }
        `;
        
        csInterface.evalScript(jsxScript, function(result) {
            console.log('Word wrapping result:', result);
        });
    }
    
    // Update the preview display
    function updatePreview() {
        var text = textInput.value || 'Preview text will appear here...';
        var width = parseInt(wrapWidth.value) || 300;
        var height = parseFloat(lineHeight.value) || 1.2;
        
        textPreview.style.width = width + 'px';
        textPreview.style.lineHeight = height;
        textPreview.textContent = text;
    }
    
    // Set the extension theme based on After Effects theme
    function setTheme() {
        var hostEnv = csInterface.getHostEnvironment();
        var theme = hostEnv.appSkinInfo.baseFontFamily;
        
        if (theme && theme.toLowerCase().includes('dark')) {
            document.body.classList.add('dark-theme');
        }
    }
    
    // Handle extension lifecycle events
    csInterface.addEventListener(CSInterface.THEME_COLOR_CHANGED_EVENT, setTheme);
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
})();
